# Sample Condominium Corporation — Notice of Annual General Meeting
To all owners and registered mortgagees:
The Annual General Meeting will be held on 2027-03-15 at ____ (time) at ____ (place / online link).
Agenda: 1. Call to order and quorum  2. Proof of notice  3. Minutes of last AGM  4. Financial statements for the
year ended 2026-12-31  5. Reserve fund report  6. Budget  7. Election of directors  8. Other business  9. Adjournment.
Enclosed: financial statements, reserve fund report, budget, proxy form.
Issued on ____ by order of the board.
This kit is an organizer for volunteer condominium boards in Alberta. It is not legal advice. Verify every date against the Condominium Property Act, the Condominium Property Regulation and your corporation's bylaws.
