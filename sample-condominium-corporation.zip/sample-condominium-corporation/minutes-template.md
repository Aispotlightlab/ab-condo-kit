# Sample Condominium Corporation — Board meeting minutes
Date: ____  Time: ____  Location/online: ____
Present (directors): ____   Regrets: ____   Quorum met: yes / no   Chair: ____  Recorder: ____
1. Call to order ____
2. Approval of agenda — moved ____ seconded ____ carried
3. Approval of previous minutes (date ____) — moved ____ seconded ____ carried
4. Financial report: bank balance ____  reserve fund balance ____  arrears ____
5. Business arising / maintenance items (item · decision · owner · due date)
6. Owner correspondence and records requests received (date · owner · request · responded on)
7. New business
8. Next meeting ____   Adjournment ____
Signed: president ____  secretary ____
This kit is an organizer for volunteer condominium boards in Alberta. It is not legal advice. Verify every date against the Condominium Property Act, the Condominium Property Regulation and your corporation's bylaws.
