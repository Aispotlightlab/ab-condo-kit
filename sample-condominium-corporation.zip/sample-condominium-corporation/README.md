# Sample Condominium Corporation — self-managed board kit (Alberta)
Files: calendar.csv / calendar.ics (12-month dated compliance calendar), minutes-template.md,
agm-notice-template.md, records-request-log.csv (CDRT-exposed item: log every owner document request and the
response date — the tribunal hears records-access disputes).
Import calendar.ics into Google/Apple/Outlook calendar. This kit is an organizer for volunteer condominium boards in Alberta. It is not legal advice. Verify every date against the Condominium Property Act, the Condominium Property Regulation and your corporation's bylaws.
